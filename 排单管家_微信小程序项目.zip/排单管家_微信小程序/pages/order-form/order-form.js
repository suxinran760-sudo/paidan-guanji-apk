
const db=require('../../utils/db');
Page({
 data:{id:'',title:'',customerName:'',amount:'',startDate:'',dueDate:'',priority:'2',status:'pending',note:'',customers:[],statusOptions:[{label:'待处理',value:'pending'},{label:'制作中',value:'doing'},{label:'待审核',value:'review'},{label:'已完成',value:'done'}],priorityOptions:[{label:'高',value:'1'},{label:'中',value:'2'},{label:'低',value:'3'}]},
 onLoad(q){const d=db.getDB();this.setData({customers:d.customers});if(q.id){const o=d.orders.find(x=>x.id===q.id);if(o)this.setData({...o,id:o.id,priority:String(o.priority||2)});}},
 input(e){this.setData({[e.currentTarget.dataset.key]:e.detail.value});},
 pickDate(e){this.setData({[e.currentTarget.dataset.key]:e.detail.value});},
 pickStatus(e){const v=this.data.statusOptions[Number(e.detail.value)];if(v)this.setData({status:v.value});},
 pickPriority(e){const v=this.data.priorityOptions[Number(e.detail.value)];if(v)this.setData({priority:v.value});},
 pickCustomer(e){const c=this.data.customers[Number(e.detail.value)];if(c)this.setData({customerName:c.name});},
 save(){if(!this.data.title.trim()){wx.showToast({title:'请填写订单名称',icon:'none'});return;}db.saveOrder({...this.data,priority:Number(this.data.priority)});wx.showToast({title:'已保存'});setTimeout(()=>wx.navigateBack(),400);},
 remove(){wx.showModal({title:'删除订单',content:'确定删除这笔订单吗？',success:r=>{if(r.confirm){db.deleteOrder(this.data.id);wx.navigateBack();}}});}
});


const db=require('../../utils/db');
Page({
 data:{year:0,month:0,monthText:'',days:[],selected:'',items:[],weekdays:['一','二','三','四','五','六','日']},
 onLoad(){const d=new Date();this.setData({year:d.getFullYear(),month:d.getMonth()+1,selected:db.today()},()=>this.load());},
 onShow(){this.load();},
 load(){
  const {year,month,selected}=this.data;
  const first=new Date(year,month-1,1), offset=(first.getDay()+6)%7, total=new Date(year,month,0).getDate();
  const all=db.getDB().orders, days=[];
  for(let i=0;i<offset;i++)days.push({key:'e'+i,empty:true});
  for(let n=1;n<=total;n++){const date=`${year}-${String(month).padStart(2,'0')}-${String(n).padStart(2,'0')}`;days.push({key:date,day:n,date,has:all.some(o=>o.dueDate===date)});}
  this.setData({days,monthText:`${year}年${month}月`,items:db.sortOrders(all.filter(o=>o.dueDate===selected)).map(o=>({...o,statusText:db.statusLabel(db.normalizeStatus(o))}))});
 },
 change(e){const v=e.currentTarget.dataset.v;let {year,month}=this.data;month+=Number(v);if(month<1){month=12;year--;}if(month>12){month=1;year++;}this.setData({year,month},()=>this.load());},
 select(e){this.setData({selected:e.currentTarget.dataset.date},()=>this.load());},
 add(){wx.navigateTo({url:'/pages/order-form/order-form'});},
 open(e){wx.navigateTo({url:'/pages/order-form/order-form?id='+e.currentTarget.dataset.id});}
});


const db=require('../../utils/db');
Page({
 data:{customers:[],showForm:false,id:'',name:'',phone:'',company:'',note:''},
 onShow(){this.load();},
 load(){this.setData({customers:db.getDB().customers});},
 toggle(){this.setData({showForm:!this.data.showForm,id:'',name:'',phone:'',company:'',note:''});},
 input(e){this.setData({[e.currentTarget.dataset.key]:e.detail.value});},
 edit(e){const c=this.data.customers.find(x=>x.id===e.currentTarget.dataset.id);if(c)this.setData({...c,showForm:true});},
 save(){if(!this.data.name.trim()){wx.showToast({title:'请填写客户名称',icon:'none'});return;}db.saveCustomer(this.data);this.setData({showForm:false});this.load();},
 remove(e){const id=e.currentTarget.dataset.id;wx.showModal({title:'删除客户',content:'确定删除该客户吗？订单记录不会删除。',success:r=>{if(r.confirm){db.deleteCustomer(id);this.load();}}});}
});

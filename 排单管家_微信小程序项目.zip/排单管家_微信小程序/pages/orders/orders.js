
const db=require('../../utils/db');
Page({
 data:{orders:[],keyword:'',filter:'all',filters:[{label:'全部',value:'all'},{label:'待处理',value:'pending'},{label:'制作中',value:'doing'},{label:'待审核',value:'review'},{label:'已完成',value:'done'},{label:'逾期',value:'overdue'}]},
 onShow(){this.load();},
 load(){const d=db.getDB();let list=db.sortOrders(d.orders);if(this.data.keyword)list=list.filter(o=>(o.title||'').includes(this.data.keyword)||(o.customerName||'').includes(this.data.keyword));if(this.data.filter!=='all')list=list.filter(o=>db.normalizeStatus(o)===this.data.filter);this.setData({orders:list.map(o=>({...o,statusText:db.statusLabel(db.normalizeStatus(o)),priorityText:['','高','中','低'][o.priority||2]}))});},
 search(e){this.setData({keyword:e.detail.value},()=>this.load());},
 choose(e){this.setData({filter:e.currentTarget.dataset.value},()=>this.load());},
 add(){wx.navigateTo({url:'/pages/order-form/order-form'});},
 open(e){wx.navigateTo({url:'/pages/order-form/order-form?id='+e.currentTarget.dataset.id});}
});

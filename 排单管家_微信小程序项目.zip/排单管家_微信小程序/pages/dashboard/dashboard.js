
const db=require('../../utils/db');
Page({
 data:{today:'',total:0,pending:0,doing:0,done:0,overdue:0,upcoming:[],progress:0},
 onShow(){this.load();},
 load(){
  const d=db.getDB(), list=db.sortOrders(d.orders), t=db.today();
  const count=s=>d.orders.filter(o=>db.normalizeStatus(o)===s).length;
  const active=d.orders.filter(o=>o.status!=='done').length;
  this.setData({today:t,total:d.orders.length,pending:count('pending'),doing:count('doing'),done:count('done'),overdue:count('overdue'),
   upcoming:list.filter(o=>o.status!=='done').slice(0,5).map(o=>({...o,statusText:db.statusLabel(db.normalizeStatus(o))})),
   progress:d.orders.length?Math.round(count('done')/d.orders.length*100):0});
 },
 add(){wx.navigateTo({url:'/pages/order-form/order-form'});},
 goOrders(){wx.switchTab({url:'/pages/orders/orders'});},
 goCalendar(){wx.switchTab({url:'/pages/calendar/calendar'});},
 open(e){wx.navigateTo({url:'/pages/order-form/order-form?id='+e.currentTarget.dataset.id});}
});

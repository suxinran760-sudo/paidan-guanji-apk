
const db=require('../../utils/db');
Page({
 data:{total:0,done:0,active:0,overdue:0,amount:'0.00',rate:0,byStatus:[]},
 onShow(){this.load();},
 load(){const orders=db.getDB().orders;const count=s=>orders.filter(o=>db.normalizeStatus(o)===s).length;const done=count('done');const amount=orders.reduce((n,o)=>n+(Number(o.amount)||0),0);const total=orders.length;
  this.setData({total,done,active:total-done-count('overdue'),overdue:count('overdue'),amount:amount.toFixed(2),rate:total?Math.round(done/total*100):0,
   byStatus:[{name:'待处理',n:count('pending'),color:'#D5A34A'},{name:'制作中',n:count('doing'),color:'#5D91CE'},{name:'待审核',n:count('review'),color:'#9A86C9'},{name:'已完成',n:done,color:'#4B9B79'},{name:'逾期',n:count('overdue'),color:'#C66B6B'}]});
 }
});

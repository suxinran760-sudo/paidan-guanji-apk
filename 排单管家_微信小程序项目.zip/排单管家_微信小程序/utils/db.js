
const KEY = 'schedule_db';
function getDB() {
  return wx.getStorageSync(KEY) || { orders: [], customers: [] };
}
function saveDB(db) { wx.setStorageSync(KEY, db); }
function uid(prefix='ID') { return prefix + Date.now().toString(36) + Math.random().toString(36).slice(2,6); }
function today() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
function addDays(dateStr, days) {
  const d = new Date(dateStr + 'T12:00:00');
  d.setDate(d.getDate()+days);
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
function statusLabel(s) {
  return ({pending:'待处理',doing:'制作中',review:'待审核',done:'已完成',overdue:'已逾期'})[s] || '待处理';
}
function normalizeStatus(o) {
  if (o.status !== 'done' && o.dueDate && o.dueDate < today()) return 'overdue';
  return o.status || 'pending';
}
function sortOrders(orders) {
  const rank = {overdue:0, pending:1, doing:2, review:3, done:4};
  return [...orders].sort((a,b) => {
    const sa=normalizeStatus(a), sb=normalizeStatus(b);
    if (sa==='done' && sb!=='done') return 1;
    if (sb==='done' && sa!=='done') return -1;
    const pa = Number(a.priority||2), pb=Number(b.priority||2);
    if (pa!==pb) return pa-pb;
    return (a.dueDate||'9999').localeCompare(b.dueDate||'9999');
  });
}
function saveOrder(order) {
  const db=getDB();
  if (order.id) {
    const i=db.orders.findIndex(x=>x.id===order.id);
    if (i>=0) db.orders[i]={...db.orders[i],...order,updatedAt:Date.now()};
  } else {
    db.orders.push({...order,id:uid('OD'),createdAt:Date.now(),status:order.status||'pending'});
  }
  saveDB(db);
}
function deleteOrder(id) {
  const db=getDB(); db.orders=db.orders.filter(x=>x.id!==id); saveDB(db);
}
function updateStatus(id,status) {
  const db=getDB(); const o=db.orders.find(x=>x.id===id);
  if(o){o.status=status; o.updatedAt=Date.now(); saveDB(db);}
}
function saveCustomer(customer) {
  const db=getDB();
  if(customer.id) {
    const i=db.customers.findIndex(x=>x.id===customer.id);
    if(i>=0) db.customers[i]={...db.customers[i],...customer};
  } else db.customers.push({...customer,id:uid('CU'),createdAt:Date.now()});
  saveDB(db);
}
function deleteCustomer(id) {
  const db=getDB(); db.customers=db.customers.filter(x=>x.id!==id); saveDB(db);
}
module.exports={getDB,saveDB,uid,today,addDays,statusLabel,normalizeStatus,sortOrders,saveOrder,deleteOrder,updateStatus,saveCustomer,deleteCustomer};

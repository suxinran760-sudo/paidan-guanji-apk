App({
  onLaunch() {
    const db = wx.getStorageSync('schedule_db');
    if (!db) {
      wx.setStorageSync('schedule_db', { orders: [], customers: [] });
    }
  }
});

排单管家安卓项目（手机云端编译版）

说明：
1. web/index.html 是改造后的独立网页应用，订单数据保存在本机浏览器/WebView localStorage。
2. 首次版本包含工作台、订单新增/编辑/删除/状态切换、日历、客户简易管理、统计。
3. 这是转换起始版本，不是已经编译好的 APK。请先在测试数据上验证；本地数据不会自动跨设备同步，卸载应用可能清除数据。
4. 编译需要 GitHub Actions。仓库根目录需要 package.json、capacitor.config.json、web/index.html 和 .github/workflows/build-apk.yml。
5. GitHub Actions 首次执行会生成 android 工程并编译 debug APK。
